export interface CourseContent {
  id: string;
  type: 'text' | 'video' | 'file' | 'test';
  content: {
    ru: string;
    kz: string;
  };
  order: number;
}

export interface CourseModule {
  id: string;
  title: {
    ru: string;
    kz: string;
  };
  description: {
    ru: string;
    kz: string;
  };
  contents: CourseContent[];
  order: number;
}

export interface Course {
  id: string;
  title: {
    ru: string;
    kz: string;
  };
  description: {
    ru: string;
    kz: string;
  };
  type: 'mandatory' | 'periodic' | 'optional';
  status: 'draft' | 'published';
  modules: CourseModule[];
  language: 'ru' | 'kz';
  created_at: Date;
  updated_at: Date;
}