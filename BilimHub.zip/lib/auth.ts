export interface User {
  id: string;
  email: string;
  role: 'admin' | 'tutor';
  name: string;
}

export const users: User[] = [
  {
    id: '1',
    email: 'admin',
    role: 'admin',
    name: 'Администратор'
  },
  {
    id: '2',
    email: 'tutor',
    role: 'tutor',
    name: 'Преподаватель'
  }
];

export function checkCredentials(email: string, password: string): User | null {
  if (email === 'admin' && password === 'admin') {
    return users[0];
  }
  if (email === 'tutor' && password === 'tutor') {
    return users[1];
  }
  return null;
}