/** @type {import('next').NextConfig} */
const nextConfig = {
  // Отключаем предупреждения SWC
  swcMinify: false,
  webpack: (config) => {
    config.resolve.alias = {
      ...config.resolve.alias,
      // Добавляем алиасы если нужно
    };
    return config;
  },
}

module.exports = nextConfig;