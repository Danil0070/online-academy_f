'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { checkCredentials } from '@/lib/auth';

export default function LoginPage() {
  const router = useRouter();
  const [credentials, setCredentials] = useState({
    email: '',
    password: ''
  });
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = checkCredentials(credentials.email, credentials.password);
    
    if (user) {
      // В реальном приложении здесь будет сохранение сессии
      if (user.role === 'admin') {
        router.push('/admin/groups');
      } else {
        router.push('/admin/courses');
      }
    } else {
      setError('Неверный логин или пароль');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full p-8 bg-white rounded-xl shadow-sm">
        {/* Логотип */}
        <div className="flex items-center justify-center mb-8">
          <div className="relative w-10 h-10">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg transform rotate-6"></div>
            <div className="absolute inset-0 bg-gradient-to-r from-blue-700 to-blue-900 rounded-lg"></div>
            <div className="absolute inset-0 flex items-center justify-center text-white font-jakarta font-bold text-lg">
              B
            </div>
          </div>
          <div className="font-jakarta font-bold text-2xl text-gray-900 ml-2">
            <span className="text-blue-700">Bilim</span>
            <span className="text-gray-900">Hub</span>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
          Вход в систему
        </h2>

        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Логин
            </label>
            <input
              type="text"
              value={credentials.email}
              onChange={(e) => setCredentials({...credentials, email: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Пароль
            </label>
            <input
              type="password"
              value={credentials.password}
              onChange={(e) => setCredentials({...credentials, password: e.target.value})}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium"
          >
            Войти
          </button>
        </form>
      </div>
    </div>
  );
}