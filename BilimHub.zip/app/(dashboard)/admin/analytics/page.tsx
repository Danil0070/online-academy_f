'use client';
import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
         PieChart, Pie, Cell, LineChart, Line, AreaChart, Area } from 'recharts';
         import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../../components/ui/tabs';
import { Calendar, Users, Clock, TrendingUp, AlertTriangle, CheckCircle, Filter } from 'lucide-react';

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState('month');
  
  // Демо-данные
  const completionData = [
    { name: 'Янв', ОТиПБ: 85, Информ_безопасность: 65, Охрана_труда: 78 },
    { name: 'Фев', ОТиПБ: 88, Информ_безопасность: 70, Охрана_труда: 82 },
    { name: 'Мар', ОТиПБ: 92, Информ_безопасность: 76, Охрана_труда: 85 },
    { name: 'Апр', ОТиПБ: 90, Информ_безопасность: 78, Охрана_труда: 87 },
    { name: 'Май', ОТиПБ: 94, Информ_безопасность: 80, Охрана_труда: 84 },
    { name: 'Июн', ОТиПБ: 96, Информ_безопасность: 83, Охрана_труда: 88 },
  ];
  
  const ageData = [
    { name: '18-25', value: 15, color: '#8884d8' },
    { name: '26-35', value: 35, color: '#83a6ed' },
    { name: '36-45', value: 30, color: '#8dd1e1' },
    { name: '46-55', value: 15, color: '#82ca9d' },
    { name: '56+', value: 5, color: '#a4de6c' },
  ];
  
  const genderData = [
    { name: 'Мужчины', value: 65, color: '#0088FE' },
    { name: 'Женщины', value: 35, color: '#FF8042' },
  ];
  
  const departmentCompletion = [
    { name: 'АУП', completed: 92, total: 100 },
    { name: 'Производство', completed: 78, total: 100 },
    { name: 'IT отдел', completed: 95, total: 100 },
    { name: 'Продажи', completed: 82, total: 100 },
    { name: 'Логистика', completed: 71, total: 100 },
  ];

  const errorRateData = [
    { name: 'Базовая электробезопасность', rate: 35 },
    { name: 'Работа на высоте', rate: 28 },
    { name: 'Обращение с хим. веществами', rate: 42 },
    { name: 'Пожарная безопасность', rate: 22 },
    { name: 'Оказание первой помощи', rate: 38 },
  ];

  const timeSpentData = [
    { name: 'Модуль 1', АУП: 25, Производство: 35 },
    { name: 'Модуль 2', АУП: 15, Производство: 28 },
    { name: 'Модуль 3', АУП: 20, Производство: 32 },
    { name: 'Модуль 4', АУП: 18, Производство: 30 },
  ];
  
  return (
    <div>
      <div className="mb-8 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Аналитика обучения</h1>
        <div className="flex gap-4 items-center">
          <div className="flex items-center bg-white rounded-lg border p-1">
            <button 
              onClick={() => setTimeRange('week')} 
              className={`px-4 py-2 rounded-md ${timeRange === 'week' ? 'bg-gray-100' : ''}`}
            >
              Неделя
            </button>
            <button 
              onClick={() => setTimeRange('month')} 
              className={`px-4 py-2 rounded-md ${timeRange === 'month' ? 'bg-gray-100' : ''}`}
            >
              Месяц
            </button>
            <button 
              onClick={() => setTimeRange('quarter')} 
              className={`px-4 py-2 rounded-md ${timeRange === 'quarter' ? 'bg-gray-100' : ''}`}
            >
              Квартал
            </button>
            <button 
              onClick={() => setTimeRange('year')} 
              className={`px-4 py-2 rounded-md ${timeRange === 'year' ? 'bg-gray-100' : ''}`}
            >
              Год
            </button>
          </div>
          <button className="flex items-center gap-2 p-2 border rounded-lg hover:bg-gray-50">
            <Filter className="w-5 h-5 text-gray-500" />
            <span>Фильтры</span>
          </button>
        </div>
      </div>

      {/* Основные метрики */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <MetricCard 
          title="Всего сотрудников"
          value="2,458"
          trend="+4.6%"
          trendPositive={true}
          icon={<Users className="w-6 h-6 text-indigo-600" />}
        />
        <MetricCard 
          title="Активных курсов"
          value="12"
          trend="+2"
          trendPositive={true}
          icon={<Calendar className="w-6 h-6 text-blue-600" />}
        />
        <MetricCard 
          title="Среднее время"
          value="42 мин"
          trend="-3 мин"
          trendPositive={true}
          icon={<Clock className="w-6 h-6 text-green-600" />}
        />
        <MetricCard 
          title="Успешное завершение"
          value="86%"
          trend="+2.4%"
          trendPositive={true}
          icon={<CheckCircle className="w-6 h-6 text-emerald-600" />}
        />
      </div>

      <Tabs defaultValue="completion" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="completion">Прогресс обучения</TabsTrigger>
          <TabsTrigger value="demographics">Демографический анализ</TabsTrigger>
          <TabsTrigger value="performance">Эффективность</TabsTrigger>
          <TabsTrigger value="errors">Проблемные области</TabsTrigger>
        </TabsList>
        
        {/* Вкладка прогресса обучения */}
        <TabsContent value="completion">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Прогресс по курсам</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={completionData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" />
                    <Tooltip formatter={(value) => [`${value}%`, 'Прохождение']} />
                    <Legend />
                    <Line type="monotone" dataKey="ОТиПБ" stroke="#8884d8" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="Информ_безопасность" stroke="#82ca9d" />
                    <Line type="monotone" dataKey="Охрана_труда" stroke="#ffc658" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Завершение по отделам</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={departmentCompletion}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis unit="%" />
                    <Tooltip formatter={(value) => [`${value}%`, 'Завершено']} />
                    <Legend />
                    <Bar dataKey="completed" fill="#8884d8" name="Процент завершения" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Вкладка демографии */}
        <TabsContent value="demographics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Возрастной состав</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip formatter={(value) => [`${value}%`, 'Процент']} />
                    <Pie
                      data={ageData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {ageData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Гендерный состав</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip formatter={(value) => [`${value}%`, 'Процент']} />
                    <Pie
                      data={genderData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                      label={({name, percent}) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {genderData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Вкладка эффективности */}
        <TabsContent value="performance">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Среднее время на модуль (мин)</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={timeSpentData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="АУП" fill="#8884d8" />
                    <Bar dataKey="Производство" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Динамика обучения</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={completionData}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip />
                    <Area type="monotone" dataKey="ОТиПБ" stroke="#8884d8" fillOpacity={1} fill="url(#colorUv)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Вкладка проблемных областей */}
        <TabsContent value="errors">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Темы с наибольшим числом ошибок (%)</h3>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={errorRateData}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" unit="%" />
                    <YAxis dataKey="name" type="category" width={150} />
                    <Tooltip formatter={(value) => [`${value}%`, 'Процент ошибок']} />
                    <Legend />
                    <Bar dataKey="rate" fill="#ff8042" name="Процент ошибок" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-lg font-medium mb-4">Проблемные вопросы</h3>
              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex justify-between">
                    <div className="font-medium">Вопрос о заземлении оборудования</div>
                    <div className="text-red-500">68% ошибок</div>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Модуль: Электробезопасность
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex justify-between">
                    <div className="font-medium">Порядок действий при пожаре</div>
                    <div className="text-red-500">54% ошибок</div>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Модуль: Пожарная безопасность
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex justify-between">
                    <div className="font-medium">Применение СИЗ при работе на высоте</div>
                    <div className="text-red-500">49% ошибок</div>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Модуль: Работа на высоте
                  </div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex justify-between">
                    <div className="font-medium">Правила хранения химических веществ</div>
                    <div className="text-red-500">43% ошибок</div>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Модуль: Обращение с хим. веществами
                  </div>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function MetricCard({ title, value, trend, trendPositive, icon }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm">
      <div className="flex justify-between">
        <div>
          <p className="text-sm text-gray-500">{title}</p>
          <p className="text-2xl font-semibold mt-1">{value}</p>
        </div>
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-gray-50">
          {icon}
        </div>
      </div>
      <div className={`mt-2 flex items-center ${trendPositive ? 'text-green-600' : 'text-red-600'}`}>
        {trendPositive ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingUp className="w-4 h-4 mr-1 transform rotate-180" />}
        <span className="text-sm">{trend}</span>
      </div>
    </div>
  );
}