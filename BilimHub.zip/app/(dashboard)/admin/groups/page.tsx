'use client';
import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Group } from '@/lib/types';

export default function GroupsPage() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  return (
    <div>
      {/* Заголовок */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Управление группами</h1>
        <button
          onClick={() => setIsCreateModalOpen(true)} 
          className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium flex items-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Создать группу
        </button>
      </div>

      {/* Список групп */}
      {groups.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-dashed border-gray-300">
          <p className="text-gray-500">
            Пока нет созданных групп. Создайте первую группу, чтобы начать обучение.
          </p>
        </div>
      ) : (
        <div className="grid gap-6">
          {groups.map(group => (
            <div key={group.id} className="bg-white rounded-lg p-6 shadow-sm">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{group.name}</h3>
                  <p className="text-gray-500">{group.description}</p>
                </div>
                <button className="text-blue-600 hover:text-blue-700">
                  Управлять
                </button>
              </div>
              <div className="flex gap-4 text-sm text-gray-600">
                <div>
                  Студентов: {group.students.length}
                </div>
                <div>
                  Курсов: {group.courses.length}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Здесь будет модальное окно создания группы */}
    </div>
  );
}