'use client';
import { useState } from 'react';
import { useParams } from 'next/navigation';
import { 
  Globe, 
  ArrowLeft,
  Save,
  Eye,
  Send
} from 'lucide-react';

interface CourseData {
  title: {
    ru: string;
    kz: string;
  };
  description: {
    ru: string;
    kz: string;
  };
}

export default function CourseEditorPage() {
  const params = useParams();
  const isNewCourse = params.id === 'new';
  const [currentLanguage, setCurrentLanguage] = useState<'ru' | 'kz'>('ru');
  const [courseData, setCourseData] = useState<CourseData>({
    title: { ru: '', kz: '' },
    description: { ru: '', kz: '' }
  });

  return (
    <div>
      {/* Верхняя панель */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => window.history.back()}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <ArrowLeft className="w-5 h-5 text-gray-500" />
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {isNewCourse ? 'Создание курса' : 'Редактирование курса'}
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 text-gray-700 hover:text-gray-900 flex items-center gap-2">
            <Eye className="w-5 h-5" />
            Предпросмотр
          </button>
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-2">
            <Save className="w-5 h-5" />
            Сохранить черновик
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2">
            <Send className="w-5 h-5" />
            Опубликовать
          </button>
        </div>
      </div>

      {/* Переключатель языков */}
      <div className="flex items-center gap-4 mb-6">
        <Globe className="w-5 h-5 text-gray-500" />
        <div className="flex bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setCurrentLanguage('ru')}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              currentLanguage === 'ru'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Русский
          </button>
          <button
            onClick={() => setCurrentLanguage('kz')}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              currentLanguage === 'kz'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Қазақша
          </button>
        </div>
      </div>

      {/* Основная форма */}
      <div className="space-y-6">
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Основная информация
          </h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {currentLanguage === 'ru' ? 'Название курса' : 'Курс атауы'}
              </label>
              <input
                type="text"
                value={courseData.title[currentLanguage]}
                onChange={(e) => 
                  setCourseData({
                    ...courseData,
                    title: {
                      ...courseData.title,
                      [currentLanguage]: e.target.value
                    }
                  })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder={currentLanguage === 'ru' ? 'Введите название курса' : 'Курс атауын енгізіңіз'}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                {currentLanguage === 'ru' ? 'Описание' : 'Сипаттама'}
              </label>
              <textarea
                value={courseData.description[currentLanguage]}
                onChange={(e) =>
                  setCourseData({
                    ...courseData,
                    description: {
                      ...courseData.description,
                      [currentLanguage]: e.target.value
                    }
                  })
                }
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder={currentLanguage === 'ru' ? 'Введите описание курса' : 'Курс сипаттамасын енгізіңіз'}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}