'use client';
import { useState } from 'react';
import { 
 ArrowLeft,
 Save,
 Eye,
 Send,
 Plus,
 FileText,
 Video,
 TestTube,
 Languages
} from 'lucide-react';
import { useRouter } from 'next/navigation';
import ModuleEditor from '../../../../components/courses/ModuleEditor';

interface CourseData {
 title: {
   ru: string;
   kz: string;
 };
 description: {
   ru: string;
   kz: string;
 };
 type: 'mandatory' | 'periodic' | 'optional';
 modules: {
   id: string;
   title: {
     ru: string;
     kz: string;
   };
   description: {
     ru: string;
     kz: string;
   };
   contents: {
     id: string;
     type: 'text' | 'video' | 'test';
     content: {
       ru: string;
       kz: string;
     };
   }[];
 }[];
}

export default function NewCoursePage() {
 const router = useRouter();
 const [courseData, setCourseData] = useState<CourseData>({
   title: { ru: '', kz: '' },
   description: { ru: '', kz: '' },
   type: 'mandatory',
   modules: []
 });

 return (
   <div className="max-w-5xl mx-auto pb-12">
     {/* Верхняя панель */}
     <div className="flex items-center justify-between mb-8">
       <div className="flex items-center gap-4">
         <button 
           onClick={() => router.back()}
           className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
         >
           <ArrowLeft className="w-5 h-5 text-gray-500" />
         </button>
         <h1 className="text-2xl font-bold text-gray-900">
           Создание нового курса
         </h1>
       </div>
       <div className="flex items-center gap-3">
         <button className="px-4 py-2 text-gray-700 hover:text-gray-900 flex items-center gap-2">
           <Eye className="w-5 h-5" />
           Предпросмотр
         </button>
         <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 flex items-center gap-2 transition-colors">
           <Save className="w-5 h-5" />
           Сохранить черновик
         </button>
         <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2 transition-colors">
           <Send className="w-5 h-5" />
           Опубликовать
         </button>
       </div>
     </div>

     {/* Основная форма */}
     <div className="space-y-6">
       {/* Основная информация */}
       <div className="bg-white rounded-xl p-6 shadow-sm">
         <div className="flex items-center gap-2 mb-6">
           <Languages className="w-5 h-5 text-blue-600" />
           <h2 className="text-lg font-semibold text-gray-900">
             Основная информация
           </h2>
         </div>

         <div className="space-y-6">
           <div>
             <label className="block text-sm font-medium text-gray-700 mb-4">
               Название курса
             </label>
             <div className="grid grid-cols-2 gap-4">
               <div>
                 <div className="text-sm text-gray-500 mb-2">На русском</div>
                 <input
                   type="text"
                   value={courseData.title.ru}
                   onChange={(e) => 
                     setCourseData({
                       ...courseData,
                       title: {
                         ...courseData.title,
                         ru: e.target.value
                       }
                     })
                   }
                   className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                   placeholder="Введите название на русском"
                 />
               </div>
               <div>
                 <div className="text-sm text-gray-500 mb-2">Қазақша</div>
                 <input
                   type="text"
                   value={courseData.title.kz}
                   onChange={(e) => 
                     setCourseData({
                       ...courseData,
                       title: {
                         ...courseData.title,
                         kz: e.target.value
                       }
                     })
                   }
                   className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                   placeholder="Қазақша атауын енгізіңіз"
                 />
               </div>
             </div>
           </div>

           <div>
             <label className="block text-sm font-medium text-gray-700 mb-4">
               Описание курса
             </label>
             <div className="grid grid-cols-2 gap-4">
               <div>
                 <div className="text-sm text-gray-500 mb-2">На русском</div>
                 <textarea
                   value={courseData.description.ru}
                   onChange={(e) =>
                     setCourseData({
                       ...courseData,
                       description: {
                         ...courseData.description,
                         ru: e.target.value
                       }
                     })
                   }
                   rows={4}
                   className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                   placeholder="Введите описание на русском"
                 />
               </div>
               <div>
                 <div className="text-sm text-gray-500 mb-2">Қазақша</div>
                 <textarea
                   value={courseData.description.kz}
                   onChange={(e) =>
                     setCourseData({
                       ...courseData,
                       description: {
                         ...courseData.description,
                         kz: e.target.value
                       }
                     })
                   }
                   rows={4}
                   className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                   placeholder="Қазақша сипаттамасын енгізіңіз"
                 />
               </div>
             </div>
           </div>

           <div>
             <label className="block text-sm font-medium text-gray-700 mb-2">
               Тип курса
             </label>
             <select
               value={courseData.type}
               onChange={(e) =>
                 setCourseData({
                   ...courseData,
                   type: e.target.value as CourseData['type']
                 })
               }
               className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
             >
               <option value="mandatory">Обязательный</option>
               <option value="periodic">Периодический</option>
               <option value="optional">Опциональный</option>
             </select>
           </div>
         </div>
       </div>

       {/* Модули */}
       <div className="bg-white rounded-xl p-6 shadow-sm">
         <div className="flex items-center justify-between mb-6">
           <h2 className="text-lg font-semibold text-gray-900">
             Модули курса
           </h2>
           <button 
             onClick={() => {
               setCourseData({
                 ...courseData,
                 modules: [
                   ...courseData.modules,
                   {
                     id: Math.random().toString(),
                     title: { ru: '', kz: '' },
                     description: { ru: '', kz: '' },
                     contents: []
                   }
                 ]
               });
             }}
             className="flex items-center px-4 py-2 text-sm text-blue-600 hover:text-blue-700"
           >
             <Plus className="w-4 h-4 mr-2" />
             Добавить модуль
           </button>
         </div>

         {courseData.modules.length === 0 ? (
           <div className="text-center py-12 border-2 border-dashed border-gray-300 rounded-lg">
             <p className="text-gray-500">
               Добавьте первый модуль в курс
             </p>
           </div>
         ) : (
           <div className="space-y-4">
             {courseData.modules.map((module, index) => (
               <ModuleEditor
                 key={module.id}
                 module={module}
                 onChange={(updatedModule) => {
                   setCourseData({
                     ...courseData,
                     modules: courseData.modules.map(m =>
                       m.id === updatedModule.id ? updatedModule : m
                     )
                   });
                 }}
                 onDelete={() => {
                   setCourseData({
                     ...courseData,
                     modules: courseData.modules.filter(m => m.id !== module.id)
                   });
                 }}
               />
             ))}
           </div>
         )}
       </div>
     </div>
   </div>
 );
}