'use client';
import { useState } from 'react';
import { Plus, Search, Clock, Users, BookOpen } from 'lucide-react';
import { useRouter } from 'next/navigation';

interface Course {
  id: string;
  title: string;
  description: string;
  type: 'mandatory' | 'periodic' | 'optional';
  status: 'draft' | 'published';
  periodicity?: {
    type: 'monthly' | 'quarterly' | 'yearly';
  };
}

export default function CoursesPage() {
  const router = useRouter();
  const [courses, setCourses] = useState<Course[]>([]);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  return (
    <div>
      {/* Заголовок */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Управление курсами</h1>
        <button
          onClick={() => router.push('/admin/courses/new')}
          className="px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium flex items-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Создать курс
        </button>
      </div>

      {/* Фильтры */}
      <div className="flex gap-4 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Поиск курсов..."
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
          <option>Все типы</option>
          <option>Обязательные</option>
          <option>Периодические</option>
          <option>Опциональные</option>
        </select>
        <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
          <option>Все статусы</option>
          <option>Черновик</option>
          <option>Опубликован</option>
        </select>
      </div>

      {/* Список курсов */}
      {courses.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-dashed border-gray-300">
          <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500">
            Пока нет созданных курсов. Создайте первый курс, чтобы начать обучение.
          </p>
        </div>
      ) : (
        <div className="grid gap-6">
          {courses.map(course => (
            <div key={course.id} className="bg-white rounded-lg p-6 shadow-sm">
              {/* Информация о курсе */}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}