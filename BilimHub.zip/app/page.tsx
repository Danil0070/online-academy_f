'use client';
import { BookOpen, Users, Shield, Award } from 'lucide-react';
import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      {/* Навигация */}
      <nav className="fixed w-full bg-white shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              {/* Логотип */}
              <div className="flex items-center justify-center">
                <div className="relative w-10 h-10">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 rounded-lg transform rotate-6"></div>
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-700 to-blue-900 rounded-lg"></div>
                  <div className="absolute inset-0 flex items-center justify-center text-white font-jakarta font-bold text-lg">
                    B
                  </div>
                </div>
                <div className="font-jakarta font-bold text-2xl text-gray-900 ml-2">
                  <span className="text-blue-700">Bilim</span>
                  <span className="text-gray-900">Hub</span>
                </div>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <button className="text-gray-600 hover:text-gray-900 transition-colors font-medium">
                О платформе
              </button>
              <button className="text-gray-600 hover:text-gray-900 transition-colors font-medium">
                Решения
              </button>
              <button className="text-gray-600 hover:text-gray-900 transition-colors font-medium">
                Контакты
              </button>
              <Link href="/login" className="px-6 py-2.5 text-gray-700 hover:text-gray-900 transition-colors font-medium">
                Войти
              </Link>
              <button className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium">
                Связаться с нами
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero секция */}
      <section className="pt-32 pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="font-jakarta text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
              Корпоративное обучение
              <span className="block mt-2 bg-gradient-to-r from-blue-600 to-blue-800 text-transparent bg-clip-text">
                для вашей компании
              </span>
            </h1>
            <p className="mt-6 max-w-2xl mx-auto text-lg text-gray-600">
              Автоматизируйте процесс обучения, контролируйте развитие сотрудников 
              и повышайте эффективность бизнеса
            </p>
            <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4">
              <button className="px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all font-medium">
                Оставить заявку
              </button>
              <button className="px-8 py-4 border border-gray-300 text-gray-700 rounded-lg hover:border-gray-400 transition-colors font-medium">
                Узнать больше
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Статистика */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: '97%', label: 'Завершаемость курсов' },
              { number: '82%', label: 'Рост эффективности' },
              { number: '45 мин', label: 'Среднее время урока' },
              { number: '300+', label: 'Компаний выбрали нас' }
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="text-3xl font-bold text-blue-600">{stat.number}</div>
                <div className="mt-2 text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Преимущества */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 font-jakarta">
              Почему выбирают нашу платформу
            </h2>
            <p className="mt-4 text-lg text-gray-600">
              Комплексное решение для корпоративного обучения
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Users,
                title: 'Автоматическое планирование',
                description: 'Система сама формирует график обучения с учетом занятости сотрудников'
              },
              {
                icon: Shield,
                title: 'Безопасность данных',
                description: 'Защищенное хранение и передача корпоративной информации'
              },
              {
                icon: Award,
                title: 'Контроль качества',
                description: 'Мониторинг и аналитика процесса обучения в реальном времени'
              }
            ].map((feature, i) => (
              <div key={i} className="p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="w-12 h-12 rounded-lg bg-blue-50 flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}