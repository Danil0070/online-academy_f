"use client"

import * as React from "react"

const Tabs = ({ defaultValue, className, children, ...props }) => {
  const [value, setValue] = React.useState(defaultValue)
  
  return (
    <div className={className} {...props}>
      {React.Children.map(children, child => {
        if (!React.isValidElement(child)) return null;
        
        if (child.type === TabsList) {
          return React.cloneElement(child, {
            value,
            onValueChange: setValue,
          });
        }
        
        if (child.type === TabsContent) {
          return React.cloneElement(child, {
            value,
            selectedValue: value
          });
        }
        
        return child;
      })}
    </div>
  );
}

const TabsList = ({ children, value, onValueChange, className, ...props }) => (
  <div 
    className={`inline-flex h-10 items-center justify-center rounded-md bg-gray-100 p-1 text-gray-500 ${className || ''}`}
    {...props}
  >
    {React.Children.map(children, child => {
      if (!React.isValidElement(child)) return null;
      return React.cloneElement(child, {
        value,
        onValueChange,
      });
    })}
  </div>
);

const TabsTrigger = ({ children, value: childValue, onValueChange, value: selectedValue, className, ...props }) => (
  <button 
    className={`inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1.5 text-sm font-medium transition-all 
      ${selectedValue === childValue ? 'bg-white text-gray-950 shadow-sm' : 'hover:bg-gray-200'} 
      ${className || ''}`}
    onClick={() => onValueChange(childValue)}
    {...props}
  >
    {children}
  </button>
);

const TabsContent = ({ children, value: childValue, selectedValue, className, ...props }) => {
  if (childValue !== selectedValue) return null;
  
  return (
    <div 
      className={`mt-2 ${className || ''}`}
      {...props}
    >
      {children}
    </div>
  );
};

export { Tabs, TabsList, TabsTrigger, TabsContent }