'use client';
import { useState } from 'react';
import { 
  GripVertical,
  Plus,
  Trash2,
  FileText,
  Video,
  TestTube,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import LessonEditor from './LessonEditor';
import VideoLessonEditor from './VideoLessonEditor';
import TestEditor from './TestEditor';

interface ModuleContent {
  id: string;
  type: 'text' | 'video' | 'test';
  content: {
    ru: string;
    kz: string;
  };
}

interface Module {
  id: string;
  title: {
    ru: string;
    kz: string;
  };
  description: {
    ru: string;
    kz: string;
  };
  contents: ModuleContent[];
}

interface ModuleEditorProps {
  module: Module;
  onChange: (module: Module) => void;
  onDelete: () => void;
}

export default function ModuleEditor({ module, onChange, onDelete }: ModuleEditorProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  const addContent = (type: ModuleContent['type']) => {
    const newContent: ModuleContent = {
      id: Math.random().toString(),
      type,
      content: { ru: '', kz: '' }
    };
    onChange({
      ...module,
      contents: [...module.contents, newContent]
    });
  };

  const deleteContent = (contentId: string) => {
    onChange({
      ...module,
      contents: module.contents.filter(c => c.id !== contentId)
    });
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      {/* Заголовок модуля */}
      <div className="p-4 bg-gray-50 border-b border-gray-200">
        <div className="flex items-start gap-4">
          <GripVertical className="w-5 h-5 text-gray-400 mt-2" />
          <div className="flex-1">
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <div className="text-sm text-gray-500 mb-1">Название на русском</div>
                <input
                  type="text"
                  value={module.title.ru}
                  onChange={(e) => onChange({
                    ...module,
                    title: { ...module.title, ru: e.target.value }
                  })}
                  className="w-full px-3 py-1.5 border border-gray-300 rounded-md"
                  placeholder="Введите название модуля"
                />
              </div>
              <div>
                <div className="text-sm text-gray-500 mb-1">Қазақша атауы</div>
                <input
                  type="text"
                  value={module.title.kz}
                  onChange={(e) => onChange({
                    ...module,
                    title: { ...module.title, kz: e.target.value }
                  })}
                  className="w-full px-3 py-1.5 border border-gray-300 rounded-md"
                  placeholder="Модуль атауын енгізіңіз"
                />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setIsExpanded(!isExpanded)}
                className="text-gray-600 hover:text-gray-900"
              >
                {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
              </button>
              <button 
                onClick={onDelete}
                className="text-red-600 hover:text-red-700 ml-auto"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Содержимое модуля */}
      {isExpanded && (
        <div className="p-4">
          {/* Список уроков */}
          <div className="space-y-4">
            {module.contents.map((content, index) => (
              <div key={content.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <GripVertical className="w-5 h-5 text-gray-400" />
                    {content.type === 'text' && <FileText className="w-5 h-5 text-blue-500" />}
                    {content.type === 'video' && <Video className="w-5 h-5 text-blue-500" />}
                    {content.type === 'test' && <TestTube className="w-5 h-5 text-blue-500" />}
                    <span className="font-medium">
                      {content.type === 'text' && 'Текстовый урок'}
                      {content.type === 'video' && 'Видео урок'}
                      {content.type === 'test' && 'Тест'}
                      {' '}#{index + 1}
                    </span>
                  </div>
                  <button 
                    onClick={() => deleteContent(content.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                {/* Редактор контента в зависимости от типа */}
                {content.type === 'text' && (
                  <LessonEditor 
                    content={content.content} 
                    onChange={(newContent) => onChange({
                      ...module,
                      contents: module.contents.map(c => 
                        c.id === content.id ? { ...c, content: newContent } : c
                      )
                    })}
                  />
                )}

                {content.type === 'video' && (
                  <VideoLessonEditor 
                    content={content.content}
                    onChange={(newContent) => onChange({
                      ...module,
                      contents: module.contents.map(c => 
                        c.id === content.id ? { ...c, content: newContent } : c
                      )
                    })}
                  />
                )}

                {content.type === 'test' && (
                  <TestEditor 
                    content={content.content}
                    onChange={(newContent) => onChange({
                      ...module,
                      contents: module.contents.map(c => 
                        c.id === content.id ? { ...c, content: newContent } : c
                      )
                    })}
                  />
                )}
              </div>
            ))}
          </div>

          {/* Кнопки добавления контента */}
          <div className="mt-4 flex gap-2">
            <button
              onClick={() => addContent('text')}
              className="flex items-center px-3 py-2 text-sm text-gray-700 hover:text-gray-900 bg-gray-50 rounded-md"
            >
              <FileText className="w-4 h-4 mr-2" />
              Текстовый урок
            </button>
            <button
              onClick={() => addContent('video')}
              className="flex items-center px-3 py-2 text-sm text-gray-700 hover:text-gray-900 bg-gray-50 rounded-md"
            >
              <Video className="w-4 h-4 mr-2" />
              Видео урок
            </button>
            <button
              onClick={() => addContent('test')}
              className="flex items-center px-3 py-2 text-sm text-gray-700 hover:text-gray-900 bg-gray-50 rounded-md"
            >
              <TestTube className="w-4 h-4 mr-2" />
              Тест
            </button>
          </div>
        </div>
      )}
    </div>
  );
}