'use client';
import { useState } from 'react';
import { Plus, Trash2, GripVertical, Globe } from 'lucide-react';

interface Question {
  id: string;
  type: 'single' | 'multiple' | 'text';
  content: {
    ru: {
      question: string;
      options?: { id: string; text: string; isCorrect: boolean; }[];
      correctAnswer?: string;
    };
    kz: {
      question: string;
      options?: { id: string; text: string; isCorrect: boolean; }[];
      correctAnswer?: string;
    };
  };
}

interface TestEditorProps {
  initialContent?: {
    title: string;
    questions: Question[];
  };
  onChange: (content: any) => void;
}

export default function TestEditor({ initialContent, onChange }: TestEditorProps) {
  const [activeLanguage, setActiveLanguage] = useState<'ru' | 'kz'>('ru');
  const [test, setTest] = useState({
    title: initialContent?.title || '',
    questions: initialContent?.questions || []
  });

  const addQuestion = (type: Question['type']) => {
    const newQuestion: Question = {
      id: Math.random().toString(),
      type,
      content: {
        ru: {
          question: '',
          ...(type !== 'text' && {
            options: [{ id: Math.random().toString(), text: '', isCorrect: false }]
          }),
          ...(type === 'text' && { correctAnswer: '' })
        },
        kz: {
          question: '',
          ...(type !== 'text' && {
            options: [{ id: Math.random().toString(), text: '', isCorrect: false }]
          }),
          ...(type === 'text' && { correctAnswer: '' })
        }
      }
    };

    const newTest = {
      ...test,
      questions: [...test.questions, newQuestion]
    };
    
    setTest(newTest);
    onChange(newTest);
  };

  return (
    <div className="space-y-6 bg-white rounded-xl p-6">
      {/* Переключатель языка контента */}
      <div className="flex items-center justify-end gap-4 mb-6">
        <div className="text-sm text-gray-500">Язык контента:</div>
        <div className="flex bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setActiveLanguage('ru')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeLanguage === 'ru'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            RU
          </button>
          <button
            onClick={() => setActiveLanguage('kz')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeLanguage === 'kz'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            KZ
          </button>
        </div>
      </div>

      {/* Название теста */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Название теста
        </label>
        <input
          type="text"
          value={test.title}
          onChange={(e) => {
            const newTest = { ...test, title: e.target.value };
            setTest(newTest);
            onChange(newTest);
          }}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Введите название теста"
        />
      </div>

      {/* Список вопросов */}
      {/* здесь будет код вопросов */}

      {/* Кнопки добавления вопросов */}
      <div className="flex gap-2">
        <button
          onClick={() => addQuestion('single')}
          className="px-4 py-2 text-sm bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100"
        >
          Один правильный ответ
        </button>
        <button
          onClick={() => addQuestion('multiple')}
          className="px-4 py-2 text-sm bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100"
        >
          Несколько правильных ответов
        </button>
        <button
          onClick={() => addQuestion('text')}
          className="px-4 py-2 text-sm bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100"
        >
          Текстовый ответ
        </button>
      </div>
    </div>
  );
}