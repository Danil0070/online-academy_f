'use client';
import { useState } from 'react';
import { Upload, X, PlayCircle } from 'lucide-react';

interface VideoLessonEditorProps {
  content: {
    ru: string;
    kz: string;
  };
  onChange: (content: { ru: string; kz: string }) => void;
}

export default function VideoLessonEditor({ content, onChange }: VideoLessonEditorProps) {
  const [uploading, setUploading] = useState(false);

  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Русская версия */}
      <div className="space-y-4">
        <div className="text-sm text-gray-600">Видео на русском</div>
        {content.ru ? (
          <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
            <video 
              src={content.ru} 
              controls 
              className="w-full h-full"
            />
            <button 
              onClick={() => onChange({ ...content, ru: '' })}
              className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-sm"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <button 
              onClick={() => {
                // Здесь будет логика загрузки
              }}
              className="flex flex-col items-center gap-2"
              disabled={uploading}
            >
              <Upload className="w-8 h-8 text-gray-400" />
              <span className="text-sm text-gray-600">
                {uploading ? 'Загрузка...' : 'Загрузить видео'}
              </span>
            </button>
          </div>
        )}
        <textarea
          placeholder="Описание видео на русском"
          className="w-full px-3 py-2 border rounded-md"
          rows={3}
        />
      </div>

      {/* Казахская версия */}
      <div className="space-y-4">
        <div className="text-sm text-gray-600">Қазақша видео</div>
        {content.kz ? (
          <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden">
            <video 
              src={content.kz} 
              controls 
              className="w-full h-full"
            />
            <button 
              onClick={() => onChange({ ...content, kz: '' })}
              className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-sm"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <button 
              onClick={() => {
                // Здесь будет логика загрузки
              }}
              className="flex flex-col items-center gap-2"
              disabled={uploading}
            >
              <Upload className="w-8 h-8 text-gray-400" />
              <span className="text-sm text-gray-600">
                {uploading ? 'Жүктелуде...' : 'Видео жүктеу'}
              </span>
            </button>
          </div>
        )}
        <textarea
          placeholder="Қазақша видео сипаттамасы"
          className="w-full px-3 py-2 border rounded-md"
          rows={3}
        />
      </div>
    </div>
  );
}