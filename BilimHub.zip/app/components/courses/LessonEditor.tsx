'use client';
import { useState } from 'react';
import RichEditor from './RichEditor';
import { Globe } from 'lucide-react';

interface LessonEditorProps {
  content: {
    ru: string;
    kz: string;
  };
  onChange: (content: { ru: string; kz: string }) => void;
}

export default function LessonEditor({ content, onChange }: LessonEditorProps) {
  const [activeLanguage, setActiveLanguage] = useState<'ru' | 'kz'>('ru');

  return (
    <div className="space-y-4">
      <div className="flex justify-end items-center gap-2">
        <Globe className="h-4 w-4 text-gray-500" />
        <select
          value={activeLanguage}
          onChange={(e) => setActiveLanguage(e.target.value as 'ru' | 'kz')}
          className="text-sm border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        >
          <option value="ru">Русский текст</option>
          <option value="kz">Казахский текст</option>
        </select>
      </div>

      <RichEditor
        content={content[activeLanguage]}
        onChange={(newContent) => {
          onChange({
            ...content,
            [activeLanguage]: newContent
          });
        }}
        placeholder={activeLanguage === 'ru' ? 'Введите текст урока...' : 'Сабақ мәтінін енгізіңіз...'}
      />

      <div className="flex justify-end gap-4 text-sm text-gray-500">
        {content.ru && (
          <span className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            Русский текст заполнен
          </span>
        )}
        {content.kz && (
          <span className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            Казахский текст заполнен
          </span>
        )}
      </div>
    </div>
  );
}