'use client';
import { useState } from 'react';
import { Course, CourseModule } from '@/lib/course-types';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '@/components/ui/tabs';
import { 
  BookOpen, 
  Globe, 
  FileText, 
  Video, 
  TestTube, 
  Plus 
} from 'lucide-react';

interface CourseEditorProps {
  initialData?: Course;
}

export default function CourseEditor({ initialData }: CourseEditorProps) {
  const [currentLanguage, setCurrentLanguage] = useState<'ru' | 'kz'>('ru');
  const [course, setCourse] = useState<Course>(initialData || {
    id: '',
    title: { ru: '', kz: '' },
    description: { ru: '', kz: '' },
    type: 'mandatory',
    status: 'draft',
    modules: [],
    language: 'ru',
    created_at: new Date(),
    updated_at: new Date()
  });

  return (
    <div className="max-w-5xl mx-auto py-8">
      {/* Заголовок и кнопки */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900">
          {course.id ? 'Редактирование курса' : 'Создание нового курса'}
        </h1>
        <div className="flex gap-3">
          <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
            Предпросмотр
          </button>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Опубликовать
          </button>
        </div>
      </div>

      {/* Переключатель языков */}
      <div className="flex items-center gap-4 mb-6">
        <Globe className="w-5 h-5 text-gray-500" />
        <div className="flex bg-gray-100 rounded-lg p-1">
          <button
            onClick={() => setCurrentLanguage('ru')}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              currentLanguage === 'ru'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Русский
          </button>
          <button
            onClick={() => setCurrentLanguage('kz')}
            className={`px-4 py-2 rounded-md text-sm font-medium ${
              currentLanguage === 'kz'
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            Қазақша
          </button>
        </div>
      </div>

      {/* Основная форма */}
      <div className="space-y-6">
        {/* Основная информация */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            Основная информация
          </h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Название курса
              </label>
              <input
                type="text"
                value={course.title[currentLanguage]}
                onChange={(e) => 
                  setCourse({
                    ...course,
                    title: {
                      ...course.title,
                      [currentLanguage]: e.target.value
                    }
                  })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Описание
              </label>
              <textarea
                value={course.description[currentLanguage]}
                onChange={(e) =>
                  setCourse({
                    ...course,
                    description: {
                      ...course.description,
                      [currentLanguage]: e.target.value
                    }
                  })
                }
                rows={4}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Тип курса
              </label>
              <select
                value={course.type}
                onChange={(e) =>
                  setCourse({
                    ...course,
                    type: e.target.value as Course['type']
                  })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="mandatory">Обязательный</option>
                <option value="periodic">Периодический</option>
                <option value="optional">Опциональный</option>
              </select>
            </div>
          </div>
        </div>

        {/* Модули */}
        <div className="bg-white rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">
              Модули курса
            </h2>
            <button className="flex items-center px-4 py-2 text-sm text-blue-600 hover:text-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Добавить модуль
            </button>
          </div>

          {/* Список модулей будет здесь */}
        </div>
      </div>
    </div>
  );
}